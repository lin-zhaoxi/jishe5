模块三 SVG 图标包

说明
- 本压缩包基于你提供的三张“徽州木雕 / 石雕 / 砖雕”设计图中的小图标元素，提取并矢量化为单独 SVG。
- 每个 SVG 均为透明背景，路径填充使用 currentColor，可直接在网页里通过 CSS 改色。
- 文件按 wood / stone / brick 三个目录分类。
- 另外附带 preview_sheet.png 预览总表。

使用建议
- HTML 直接引用：<img src="./wood/wood_material_logs.svg" alt="木雕-选材" />
- CSS 改色（内联 SVG / mask / background-image 场景更方便）：color: #6B4C3B;
- 推荐放在 24 / 32 / 40 / 48 / 64 像素等尺寸使用。
